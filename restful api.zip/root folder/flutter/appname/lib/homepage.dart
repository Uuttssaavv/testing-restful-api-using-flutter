import 'dart:io';

import 'package:appname/article.dart';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

class Homepage extends StatefulWidget {
  Homepage({Key key}) : super(key: key);
  @override
  _HomepageState createState() => _HomepageState();
}

class _HomepageState extends State<Homepage> {
  List<Article> articles = [];
  String windowsbaseUrl = 'http://192.168.1.64:8000';
  String linuxBaseUrl = 'http://192.168.43.50:8000';
  @override
  void initState() {
    super.initState();
    fetchFromAPi();
  }

  fetchFromAPi() async {
    try {
      http.Response response = await http
          .get('$linuxBaseUrl/article/get/'); //choose base url as per your OS
      articles = articleFromJson(response.body);
      setState(() {});
    } on SocketException catch (e) {
      print(e.toString()); //catch and print exceptions
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(
          title: Text("Api from Localhost"),
          centerTitle: true,
        ),
        body: ListView.builder(
            shrinkWrap: true,
            itemCount: articles.length,
            itemBuilder: (BuildContext context, int index) {
              return ListTile(
                  leading: CircleAvatar(
                    child: Text("${articles[index].id}"),
                  ),
                  title: Text("${articles[index].title}"),
                  subtitle: Text("${articles[index].description}"));
            }));
  }
}
