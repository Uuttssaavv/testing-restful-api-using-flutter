from django.apps import AppConfig


class RestfulapiConfig(AppConfig):
    name = 'restfulapi'
